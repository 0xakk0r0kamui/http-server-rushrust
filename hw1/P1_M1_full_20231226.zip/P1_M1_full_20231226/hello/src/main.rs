fn main() {
  let s : &str = "Helloooooooooooooooooooooo!";
  println!("{}", s);
}
